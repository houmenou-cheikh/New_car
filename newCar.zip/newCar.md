# Projet new car


```python
import pandas
car_data = pandas.read_csv("carData.csv",sep = ',')


#dimensions : nombre de lignes, nombre de colonnes
#la ligne d'en-tête n'est pas comptabilisée
#dans le nombre de lignes
print(car_data.shape)
#énumération des colonnes
print(car_data.columns)


```

    (301, 9)
    Index(['Car_Name', 'Year', 'Selling_Price', 'Present_Price', 'Kms_Driven',
           'Fuel_Type', 'Seller_Type', 'Transmission', 'Owner'],
          dtype='object')



```python
#affichage de quelques données
print(car_data.head())
```

      Car_Name  Year  Selling_Price  Present_Price  Kms_Driven Fuel_Type  \
    0     ritz  2014           3.35           5.59       27000    Petrol   
    1      sx4  2013           4.75           9.54       43000    Diesel   
    2     ciaz  2017           7.25           9.85        6900    Petrol   
    3  wagon r  2011           2.85           4.15        5200    Petrol   
    4    swift  2014           4.60           6.87       42450    Diesel   
    
      Seller_Type Transmission  Owner  
    0      Dealer       Manual      0  
    1      Dealer       Manual      0  
    2      Dealer       Manual      0  
    3      Dealer       Manual      0  
    4      Dealer       Manual      0  


 # Définition des carateristiques:
 
    
    Car_Name : Cette colonne doit être remplie avec le nom de la voiture.
    ● Year:    Cette colonne doit être remplie avec l'année de fabrication de la voiture.
    ● Selling_Price: cette colonne doit être remplie avec le prix auquel le propriétaire
                      souhaite vendre la voiture.
    ● Kms_Driven :  Il s'agit de la distance parcourue par la voiture en km.
    ● Fuel_Type :   Type de carburant de la voiture.
    ● Seller_Type : définit si le vendeur est un revendeur ou un particulier.
    ● Transmission: définit si la boite de vitesse de la voiture est manuelle ou automatique.


```python
car_data.describe(include='all')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Car_Name</th>
      <th>Year</th>
      <th>Selling_Price</th>
      <th>Present_Price</th>
      <th>Kms_Driven</th>
      <th>Fuel_Type</th>
      <th>Seller_Type</th>
      <th>Transmission</th>
      <th>Owner</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>301</td>
      <td>301.000000</td>
      <td>301.000000</td>
      <td>301.000000</td>
      <td>301.000000</td>
      <td>301</td>
      <td>301</td>
      <td>301</td>
      <td>301.000000</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>98</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>3</td>
      <td>2</td>
      <td>2</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>top</th>
      <td>city</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Petrol</td>
      <td>Dealer</td>
      <td>Manual</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>26</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>239</td>
      <td>195</td>
      <td>261</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>NaN</td>
      <td>2013.627907</td>
      <td>4.661296</td>
      <td>7.628472</td>
      <td>36947.205980</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.043189</td>
    </tr>
    <tr>
      <th>std</th>
      <td>NaN</td>
      <td>2.891554</td>
      <td>5.082812</td>
      <td>8.644115</td>
      <td>38886.883882</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.247915</td>
    </tr>
    <tr>
      <th>min</th>
      <td>NaN</td>
      <td>2003.000000</td>
      <td>0.100000</td>
      <td>0.320000</td>
      <td>500.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>NaN</td>
      <td>2012.000000</td>
      <td>0.900000</td>
      <td>1.200000</td>
      <td>15000.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>NaN</td>
      <td>2014.000000</td>
      <td>3.600000</td>
      <td>6.400000</td>
      <td>32000.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>NaN</td>
      <td>2016.000000</td>
      <td>6.000000</td>
      <td>9.900000</td>
      <td>48767.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>NaN</td>
      <td>2018.000000</td>
      <td>35.000000</td>
      <td>92.600000</td>
      <td>500000.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>3.000000</td>
    </tr>
  </tbody>
</table>
</div>



    #quelques statistiques de base (moyenne, médiane,quartile,Ecart-type)


```python
car_data.Car_Name.describe()
```




    count      301
    unique      98
    top       city
    freq        26
    Name: Car_Name, dtype: object




```python
car_data.Kms_Driven.describe()
```




    count       301.000000
    mean      36947.205980
    std       38886.883882
    min         500.000000
    25%       15000.000000
    50%       32000.000000
    75%       48767.000000
    max      500000.000000
    Name: Kms_Driven, dtype: float64




```python
car_data.Present_Price.describe()
```




    count    301.000000
    mean       7.628472
    std        8.644115
    min        0.320000
    25%        1.200000
    50%        6.400000
    75%        9.900000
    max       92.600000
    Name: Present_Price, dtype: float64



# tracer la distribution avec Matplotlib (histogramme)


```python
import matplotlib.pyplot as plt

data = car_data.Present_Price

plt.hist(data)

plt.title('histogramme des prix actuels ', fontsize=10)

#plt.savefig("plot_simple_histogramme_matplotlib_01.png")

plt.show()
```


    
![png](output_10_0.png)
    



```python
plt.hist(car_data.Year)

plt.title('histogramme sur les noms de voiture ', fontsize=10)

plt.show()
```


    
![png](output_11_0.png)
    



```python
plt.hist(car_data.Car_Name[:10])

plt.title('histogramme sur les kilometrage des voitures ', fontsize=10)

plt.show()
```


    
![png](output_12_0.png)
    



```python
plt.hist(car_data.Selling_Price)

plt.title('histogramme sur les kilometrage des voitures ', fontsize=10)

plt.show()


```


    
![png](output_13_0.png)
    


# Visualisez les données grâce à la librairie Seaborn


```python
import seaborn



a4_dims = (11.7, 8.27)

fig, ax = plt.subplots(figsize=a4_dims)
seaborn.violinplot(ax=ax, data=car_data)
seaborn.catplot(data=car_data, height=8.27, aspect=11.7/8.27)
plt.show()
```


    
![png](output_15_0.png)
    



    
![png](output_15_1.png)
    



```python
fig, ax = plt.subplots(figsize=a4_dims)
seaborn.violinplot(ax=ax, data=car_data.Kms_Driven)
plt.show()
```


    
![png](output_16_0.png)
    


# Regression lineaire
# Quantifiez la relation entre l'âge et le prix de vente


```python
seaborn.jointplot(car_data.Year, car_data.Present_Price,kind='reg')
plt.show()
```

    /home/houmenou/Téléchargements/cf2ff493f11eaad5d09ce2b4feaa5ea90db5174303d5b3fe030e16d29aeef7de/lib/python3.8/site-packages/seaborn/_decorators.py:36: FutureWarning: Pass the following variables as keyword args: x, y. From version 0.12, the only valid positional argument will be `data`, and passing other arguments without an explicit keyword will result in an error or misinterpretation.
      warnings.warn(



    
![png](output_18_1.png)
    


# outil de visualisation Matplotlib permettant d'appuyer notre argumentation

### ● Appliquer l’algorithme de régression linéaire univariée en vous aidant de la
            librairie Scipy.


```python
from scipy import stats
#linregress() renvoie plusieurs variables de retour. On s'interessera 
# particulierement au slope et intercept

axes = plt.axes()
axes.grid() # dessiner une grille pour une meilleur lisibilité du graphe
plt.scatter(car_data.Year, car_data.Present_Price) # X et Y sont les variables qu'on a extraite dans le paragraphe précédent
slope, intercept, r_value, p_value, std_err = stats.linregress(car_data.Year, car_data.Present_Price)
def predict(x):
   return slope * x + intercept

#la variable fitLine sera un tableau de valeurs prédites depuis la tableau de variables X
fitLine = predict(car_data.Year)
plt.plot(car_data.Year, fitLine, c='r')
plt.show()
```


    
![png](output_21_0.png)
    



```python
# Autre methode de faire
from scipy import stats

res = stats.linregress(car_data.Year, car_data.Present_Price)
print(f"R-squared: {res.rvalue**2:.6f}")

plt.plot(car_data.Year, car_data.Present_Price, 'o', label='original data')
plt.plot(car_data.Year, res.intercept + res.slope*car_data.Year, 'r', label='fitted line')
plt.legend()
plt.show()
```

    R-squared: 0.002264



    
![png](output_22_1.png)
    


### ● Appliquer l’algorithme de régression linéaire univariée en vous aidant de la
             librairie Numpy.


```python
import numpy as np

 
fit = np.polyfit(car_data.Year, car_data.Present_Price,deg=1)
print(fit)
prediction =np.poly1d(fit) #fonction polynomiale 
plt.scatter(car_data.Year, car_data.Present_Price)
plt.plot(car_data.Year,prediction(car_data.Year),'red')


plt.show()
```

    [-1.4224994e-01  2.9406692e+02]



    
![png](output_24_1.png)
    


# ● Appliquer l’algorithme de régression linéaire univariée en vous aidant de la
        librairie sklearn


```python
#etude de la correlation
import seaborn as sns 

matrice_corr = car_data.corr().round(1)
sns.heatmap(data=matrice_corr, annot=True)
```




    <AxesSubplot:>




    
![png](output_26_1.png)
    



```python
import pandas as pd  

Y = car_data.Present_Price
X=pd.DataFrame(car_data.Year)
 
       
#base d'apprentissage et base de test
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
 
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size = 0.2, random_state=5)
print(X_train.shape)
print(X_test.shape)
print(Y_train.shape)
print(Y_test.shape)


#entrainement du modèle

lmodellineaire = LinearRegression()
lmodellineaire.fit(X_train, Y_train)
y_train_predict = lmodellineaire.predict(X_train)

plt.scatter(car_data.Year, car_data.Present_Price)
plt.plot(X_train,y_train_predict,'red')


plt.show()

```

    (240, 1)
    (61, 1)
    (240,)
    (61,)



    
![png](output_27_1.png)
    


● Amélioration du modèle en utilisant plusieurs variables d'entrée , telles que
Kms_Driven et Transmission 

### Exploration et étude de faisabilité (coefficient de correlation,transfromation des données)


```python
from sklearn.preprocessing import LabelEncoder
car_data_2=car_data.apply(LabelEncoder().fit_transform)
matrice_corr1=car_data_2.corr()
fig, axe = plt.subplots(figsize =(9, 8)) 
sns.heatmap(matrice_corr1, ax = axe, cmap ="YlGnBu", linewidths = 0.1,annot=True)
```




    <AxesSubplot:>




    
![png](output_30_1.png)
    



```python
#Visualisastion des données
car_data.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Car_Name</th>
      <th>Year</th>
      <th>Selling_Price</th>
      <th>Present_Price</th>
      <th>Kms_Driven</th>
      <th>Fuel_Type</th>
      <th>Seller_Type</th>
      <th>Transmission</th>
      <th>Owner</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>ritz</td>
      <td>2014</td>
      <td>3.35</td>
      <td>5.59</td>
      <td>27000</td>
      <td>Petrol</td>
      <td>Dealer</td>
      <td>Manual</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>sx4</td>
      <td>2013</td>
      <td>4.75</td>
      <td>9.54</td>
      <td>43000</td>
      <td>Diesel</td>
      <td>Dealer</td>
      <td>Manual</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>ciaz</td>
      <td>2017</td>
      <td>7.25</td>
      <td>9.85</td>
      <td>6900</td>
      <td>Petrol</td>
      <td>Dealer</td>
      <td>Manual</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>wagon r</td>
      <td>2011</td>
      <td>2.85</td>
      <td>4.15</td>
      <td>5200</td>
      <td>Petrol</td>
      <td>Dealer</td>
      <td>Manual</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>swift</td>
      <td>2014</td>
      <td>4.60</td>
      <td>6.87</td>
      <td>42450</td>
      <td>Diesel</td>
      <td>Dealer</td>
      <td>Manual</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#affichage des nouveaux données apres transformation numérique
print(car_data_2.head())
#entete de chaque colonne
car_data_2.keys()
```

       Car_Name  Year  Selling_Price  Present_Price  Kms_Driven  Fuel_Type  \
    0        90    11             59             57          86          2   
    1        93    10             78            104         135          1   
    2        68    14            112            106          26          2   
    3        96     8             52             49          18          2   
    4        92    11             76             73         134          1   
    
       Seller_Type  Transmission  Owner  
    0            0             1      0  
    1            0             1      0  
    2            0             1      0  
    3            0             1      0  
    4            0             1      0  





    Index(['Car_Name', 'Year', 'Selling_Price', 'Present_Price', 'Kms_Driven',
           'Fuel_Type', 'Seller_Type', 'Transmission', 'Owner'],
          dtype='object')



## Évaluation de teste et du training avec appuie de score


```python
# Evaluation du training set
from sklearn.metrics import r2_score
y_train_predict = lmodellineaire.predict(X_train)
rmse = (np.sqrt(mean_squared_error(Y_train, y_train_predict)))
r2 = r2_score(Y_train, y_train_predict)
 
print('La performance du modèle sur la base dapprentissage')
print('--------------------------------------')
print('Lerreur quadratique moyenne est {}'.format(rmse))
print('le score R2 est {}'.format(r2))
print('\n')
 
# model evaluation for testing set
y_test_predict = lmodellineaire.predict(X_test)
rmse = (np.sqrt(mean_squared_error(Y_test, y_test_predict)))
r2 = r2_score(Y_test, y_test_predict)
 
print('La performance du modèle sur la base de test')
print('--------------------------------------')
print('Lerreur quadratique moyenne est {}'.format(rmse))
print('le score R2 est {}'.format(r2))

```

    La performance du modèle sur la base dapprentissage
    --------------------------------------
    Lerreur quadratique moyenne est 8.690681339055798
    le score R2 est 0.0020966689357276858
    
    
    La performance du modèle sur la base de test
    --------------------------------------
    Lerreur quadratique moyenne est 8.347938248311573
    le score R2 est -0.011856916957848185


## Étude régression multivarié


```python

#on utilise seulement 4 variables explicatives
X=pd.DataFrame(np.c_[car_data_2['Car_Name'],car_data['Year'],car_data['Kms_Driven'],
                     car_data_2['Fuel_Type'],car_data_2['Seller_Type'],car_data_2['Transmission'],car_data['Owner']], columns = ['Car_Name','Year','Kms_Driven','Fuel_Type','Seller_Type','Transmission','Owner'])
Y = car_data_2['Selling_Price']
 
#base d'apprentissage et base de test
from sklearn.model_selection import train_test_split
 
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size = 0.2, random_state=5)
print(X_train.shape)
print(X_test.shape)
print(Y_train.shape)
print(Y_test.shape)

#entrainement du modèle
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
 
lmodellineaire = LinearRegression()
lmodellineaire.fit(X_train, Y_train)


```

    (240, 7)
    (61, 7)
    (240,)
    (61,)





    LinearRegression()




```python
# Evaluation du training set
from sklearn.metrics import r2_score
y_train_predict = lmodellineaire.predict(X_train)
rmse = (np.sqrt(mean_squared_error(Y_train, y_train_predict)))
r2 = r2_score(Y_train, y_train_predict)
 
print('La performance du modèle sur la base dapprentissage')
print('--------------------------------------')
print('Lerreur quadratique moyenne est {}'.format(rmse))
print('le score R2 est {}'.format(r2))
print('\n')
 
# model evaluation for testing set
y_test_predict = lmodellineaire.predict(X_test)
rmse = (np.sqrt(mean_squared_error(Y_test, y_test_predict)))
r2 = r2_score(Y_test, y_test_predict)
 
print('La performance du modèle sur la base de test')
print('--------------------------------------')
print('Lerreur quadratique moyenne est {}'.format(rmse))
print('le score R2 est {}'.format(r2))

plt.scatter(car_data.Year, car_data.Present_Price)
#plt.plot(X_train,y_train_predict,'red')


plt.show()
```

    La performance du modèle sur la base dapprentissage
    --------------------------------------
    Lerreur quadratique moyenne est 21.927131577549712
    le score R2 est 0.7339103748039242
    
    
    La performance du modèle sur la base de test
    --------------------------------------
    Lerreur quadratique moyenne est 22.454795930186936
    le score R2 est 0.7488154775128765



    
![png](output_37_1.png)
    



```python
## évaluation d'erreur de prediction
```


```python
mse = mean_squared_error(Y_test, y_test_predict)
print(mse,lmodellineaire.intercept_,lmodellineaire.coef_)
```

    504.21786026633976 -10578.728281743695 [ 1.72479511e-01  5.31067254e+00  1.66528963e-04 -1.72963812e+01
     -5.06916165e+01 -1.95476124e+01  4.89099513e+00]



```python
car_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Car_Name</th>
      <th>Year</th>
      <th>Selling_Price</th>
      <th>Present_Price</th>
      <th>Kms_Driven</th>
      <th>Fuel_Type</th>
      <th>Seller_Type</th>
      <th>Transmission</th>
      <th>Owner</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>ritz</td>
      <td>2014</td>
      <td>3.35</td>
      <td>5.59</td>
      <td>27000</td>
      <td>Petrol</td>
      <td>Dealer</td>
      <td>Manual</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>sx4</td>
      <td>2013</td>
      <td>4.75</td>
      <td>9.54</td>
      <td>43000</td>
      <td>Diesel</td>
      <td>Dealer</td>
      <td>Manual</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>ciaz</td>
      <td>2017</td>
      <td>7.25</td>
      <td>9.85</td>
      <td>6900</td>
      <td>Petrol</td>
      <td>Dealer</td>
      <td>Manual</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>wagon r</td>
      <td>2011</td>
      <td>2.85</td>
      <td>4.15</td>
      <td>5200</td>
      <td>Petrol</td>
      <td>Dealer</td>
      <td>Manual</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>swift</td>
      <td>2014</td>
      <td>4.60</td>
      <td>6.87</td>
      <td>42450</td>
      <td>Diesel</td>
      <td>Dealer</td>
      <td>Manual</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>



# Réduction des données car besoin que des voitures à transmission Manuelle et dont l'années est supérieur à 2012 avec un Kms_Driven < 100000


```python
car_data_3=car_data[car_data.Year > 2012]
car_data_3=car_data_3[car_data_3.Kms_Driven < 100000]
car_data_3=car_data_3[car_data_3.Transmission == "Manual"]
car_data_3.drop("Transmission", axis=1)
car_data_3
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Car_Name</th>
      <th>Year</th>
      <th>Selling_Price</th>
      <th>Present_Price</th>
      <th>Kms_Driven</th>
      <th>Fuel_Type</th>
      <th>Seller_Type</th>
      <th>Transmission</th>
      <th>Owner</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>ritz</td>
      <td>2014</td>
      <td>3.35</td>
      <td>5.59</td>
      <td>27000</td>
      <td>Petrol</td>
      <td>Dealer</td>
      <td>Manual</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>sx4</td>
      <td>2013</td>
      <td>4.75</td>
      <td>9.54</td>
      <td>43000</td>
      <td>Diesel</td>
      <td>Dealer</td>
      <td>Manual</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>ciaz</td>
      <td>2017</td>
      <td>7.25</td>
      <td>9.85</td>
      <td>6900</td>
      <td>Petrol</td>
      <td>Dealer</td>
      <td>Manual</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>swift</td>
      <td>2014</td>
      <td>4.60</td>
      <td>6.87</td>
      <td>42450</td>
      <td>Diesel</td>
      <td>Dealer</td>
      <td>Manual</td>
      <td>0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>vitara brezza</td>
      <td>2018</td>
      <td>9.25</td>
      <td>9.83</td>
      <td>2071</td>
      <td>Diesel</td>
      <td>Dealer</td>
      <td>Manual</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>295</th>
      <td>city</td>
      <td>2015</td>
      <td>8.55</td>
      <td>13.09</td>
      <td>60076</td>
      <td>Diesel</td>
      <td>Dealer</td>
      <td>Manual</td>
      <td>0</td>
    </tr>
    <tr>
      <th>296</th>
      <td>city</td>
      <td>2016</td>
      <td>9.50</td>
      <td>11.60</td>
      <td>33988</td>
      <td>Diesel</td>
      <td>Dealer</td>
      <td>Manual</td>
      <td>0</td>
    </tr>
    <tr>
      <th>297</th>
      <td>brio</td>
      <td>2015</td>
      <td>4.00</td>
      <td>5.90</td>
      <td>60000</td>
      <td>Petrol</td>
      <td>Dealer</td>
      <td>Manual</td>
      <td>0</td>
    </tr>
    <tr>
      <th>299</th>
      <td>city</td>
      <td>2017</td>
      <td>11.50</td>
      <td>12.50</td>
      <td>9000</td>
      <td>Diesel</td>
      <td>Dealer</td>
      <td>Manual</td>
      <td>0</td>
    </tr>
    <tr>
      <th>300</th>
      <td>brio</td>
      <td>2016</td>
      <td>5.30</td>
      <td>5.90</td>
      <td>5464</td>
      <td>Petrol</td>
      <td>Dealer</td>
      <td>Manual</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>189 rows × 9 columns</p>
</div>



# Visualisation des nouvelles données et nouvelle étude de régression libéaire avec la méthode seaborn


```python

g = sns.jointplot(x="Year", y="Selling_Price", data=car_data_3,
                  kind="reg", truncate=False,
                  xlim=(2012, 2019), ylim=(0, 12),
                  color="m", height=15)
```


    
![png](output_44_0.png)
    


# visualisation des nouvelles données avec la méthode skleran


```python
######################################## préparation de données #########################################
from sklearn import linear_model
X = car_data_3[['Year', 'Present_Price']].values
Y = car_data_3['Selling_Price']

######################## Prepare model data point for visualization ###############################
x = X[:, 0]
y = X[:, 1]
z = Y
x_pred = np.linspace(2012, 2019, 15)   # range of porosity values
y_pred = np.linspace(0, 20, 15)  # range of brittleness values
xx_pred, yy_pred = np.meshgrid(x_pred, y_pred)
model_viz = np.array([xx_pred.flatten(), yy_pred.flatten()]).T

###################################### fitting et Training ########################################

ols = linear_model.LinearRegression()
model = ols.fit(X, Y)
predicted = model.predict(model_viz)

###################################### Evaluation de score #########################################

r2 = model.score(X, Y)

###################################### afficahge des graphes #######################################


plt.style.use('default')

fig = plt.figure(figsize=(14, 4))

ax1 = fig.add_subplot(131, projection='3d')
ax2 = fig.add_subplot(132, projection='3d')
ax3 = fig.add_subplot(133, projection='3d')

axes = [ax1, ax2, ax3]

for ax in axes:
    ax.plot(x, y, z, color='k', zorder=15, linestyle='none', marker='o', alpha=0.5)
    ax.scatter(xx_pred.flatten(), yy_pred.flatten(), predicted, facecolor=(0,0,0,0), s=20, edgecolor='#70b3f0')
    ax.set_xlabel('Year', fontsize=11)
    ax.set_ylabel('Present_Price', fontsize=11)
    ax.set_zlabel('Selling_Price', fontsize=11)
    ax.locator_params(nbins=4, axis='x')
    ax.locator_params(nbins=5, axis='x')
    
    
ax1.view_init(elev=8, azim=160)
ax2.view_init(elev=45, azim=-25)
ax3.view_init(elev=17, azim=25)

fig.suptitle('$R^2 = %.2f$' % r2, fontsize=20)

fig.tight_layout()


```


    
![png](output_46_0.png)
    


# Toute les voiture de cette nouvelle données sont des Manuelles à moins de 100000Km
# # Donc pour répondre à la question on peut juste donner la prédiction du prix selon l'année de la voiture


```python
# function for prediction
def prediction(year, presentprice):
    predictedPrice = ols.predict([[year, presentprice]])
    return predictedPrice[0].round(2)

#Example pour une voiture de 2014 
print('pour une voiture de 2014' )
print(prediction(int(2014),int(12.1)))


```

    pour une voiture de 2014
    7.79


# Autre méthode d'estimation du prix de la voiture en focntion de l'année 

## cette méthode consiste à donner l'année de la voiture qu'on souhaite acheter et de donner son budget puis l'algo vous return le prix réel de voiture que vous souhaitez acheter



```python
year=int(input('Saisissez l année de votre votre?(Year, ex: 2014) : '))
presentprice=float(input('Quel est le budget de votre sur cette voiture?(Present_Price, ex: 14.5) : '))
prediction(year, presentprice)
```

    Saisissez l année de votre votre?(Year, ex: 2014) : 2015
    Quel est le budget de votre sur cette voiture?(Present_Price, ex: 14.5) : 13.2





    9.12




```python

```
